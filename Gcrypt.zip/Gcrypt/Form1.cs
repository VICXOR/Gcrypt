﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace Gcrypt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string encryptxt = Convert.ToBase64String(Encoding.Unicode.GetBytes(textBox5.Text));
            try
            {
                MailMessage msgtop = new MailMessage();
                msgtop.From = new MailAddress(textBox1.Text, "Gcrypt Mail " + "From " + textBox1.Text);
                msgtop.To.Add(new MailAddress(textBox3.Text));
                msgtop.Subject = textBox4.Text;
                msgtop.Body = encryptxt;


                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                smtp.Credentials = new NetworkCredential(textBox1.Text, textBox2.Text);
                smtp.EnableSsl = true;
                smtp.Send(msgtop);
                MessageBox.Show("Encrypted Mail Was Sent!");
            } catch (Exception ex) { MessageBox.Show("Something Went Wrong"); }
        }
    }
}
